import argparse
import pandas as pd

from ml_pipeline.config.settings import Settings
from ml_pipeline.data.ingest import ingest_or_generate
from ml_pipeline.training.train import train_and_save
from ml_pipeline.evaluation.evaluate import evaluate_threshold
from ml_pipeline.utils.logging import get_logger

logger = get_logger(__name__)

def run_pipeline(config_path: str) -> dict:
    s = Settings.load(config_path)
    cfg = s.cfg

    seed = int(cfg["project"]["seed"])
    raw_path = cfg["paths"]["raw_data"]
    model_dir = cfg["paths"]["model_dir"]
    model_name = cfg["paths"]["model_name"]
    metrics_name = cfg["paths"]["metrics_name"]

    n_rows = int(cfg["data"]["n_rows"])

    target = cfg["features"]["target"]
    drop_columns = list(cfg["features"].get("drop_columns", []))

    test_size = float(cfg["training"]["test_size"])
    model_type = cfg["training"]["model_type"]
    model_cfg = cfg["training"].get(model_type, {})

    threshold = float(cfg["evaluation"]["threshold"])

    df = ingest_or_generate(raw_path=raw_path, n_rows=n_rows, seed=seed)

    artifacts = train_and_save(
        df,
        target=target,
        drop_columns=drop_columns,
        test_size=test_size,
        seed=seed,
        model_type=model_type,
        model_cfg=model_cfg,
        model_dir=model_dir,
        model_name=model_name,
        metrics_name=metrics_name,
    )

    # Quick threshold report on full dataset (simple demo)
    eval_result = evaluate_threshold(df, artifacts.pipeline, target=target, threshold=threshold)

    out = {
        "train_metrics": artifacts.metrics,
        "threshold_eval": eval_result,
        "model_path": str(artifacts.model_path),
        "metrics_path": str(artifacts.metrics_path),
    }
    logger.info(f"Pipeline run complete: {out['model_path']}")
    return out

def main():
    parser = argparse.ArgumentParser(description="Run the ML production pipeline.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    run = sub.add_parser("run", help="Run end-to-end pipeline.")
    run.add_argument("--config", required=True)

    args = parser.parse_args()

    if args.cmd == "run":
        run_pipeline(args.config)

if __name__ == "__main__":
    main()
