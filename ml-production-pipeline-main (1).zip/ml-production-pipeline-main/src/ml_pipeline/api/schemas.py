from pydantic import BaseModel, Field

class PredictRequest(BaseModel):
    tenure_months: int = Field(..., ge=0, le=240)
    monthly_charges: float = Field(..., ge=0, le=1000)
    contract_type: str
    has_internet: int = Field(..., ge=0, le=1)
    support_tickets_6m: int = Field(..., ge=0, le=100)
    payment_method: str

class PredictResponse(BaseModel):
    churn_probability: float
    churn_prediction: int
