from pathlib import Path
import joblib
from fastapi import FastAPI, HTTPException

from ml_pipeline.api.schemas import PredictRequest, PredictResponse

app = FastAPI(title="ML Production Pipeline - Inference API", version="0.1.0")

MODEL_PATH = Path("models/churn_model.joblib")

@app.get("/health")
def health():
    return {"status": "ok"}

def _load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run the pipeline first.")
    return joblib.load(MODEL_PATH)

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    try:
        model = _load_model()
        X = [{
            "customer_id": 0,  # unused but pipeline expects full schema if present in training
            "tenure_months": req.tenure_months,
            "monthly_charges": req.monthly_charges,
            "contract_type": req.contract_type,
            "has_internet": req.has_internet,
            "support_tickets_6m": req.support_tickets_6m,
            "payment_method": req.payment_method,
        }]
        prob = float(model.predict_proba(X)[:, 1][0])
        pred = int(prob >= 0.5)
        return PredictResponse(churn_probability=prob, churn_prediction=pred)
    except FileNotFoundError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Inference failed: {e}")
