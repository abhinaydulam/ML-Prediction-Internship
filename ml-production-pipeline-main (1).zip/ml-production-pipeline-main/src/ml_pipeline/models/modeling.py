from sklearn.linear_model import LogisticRegression

def build_model(model_type: str, model_cfg: dict):
    if model_type == "logistic_regression":
        return LogisticRegression(
            max_iter=int(model_cfg.get("max_iter", 200)),
            C=float(model_cfg.get("C", 1.0)),
            n_jobs=None,
        )
    raise ValueError(f"Unsupported model_type: {model_type}")
