from dataclasses import dataclass
from pathlib import Path
import yaml

@dataclass(frozen=True)
class Settings:
    config_path: Path
    cfg: dict

    @staticmethod
    def load(config_path: str) -> "Settings":
        path = Path(config_path)
        with path.open("r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        return Settings(config_path=path, cfg=cfg)
