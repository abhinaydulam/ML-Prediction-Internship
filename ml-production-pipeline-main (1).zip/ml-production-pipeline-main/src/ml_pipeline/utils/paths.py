from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
