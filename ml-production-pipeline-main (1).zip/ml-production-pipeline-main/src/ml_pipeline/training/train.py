from dataclasses import dataclass
from pathlib import Path
import json
import joblib
import pandas as pd

from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, average_precision_score

from ml_pipeline.features.build_features import build_preprocessor
from ml_pipeline.models.modeling import build_model
from ml_pipeline.utils.logging import get_logger

logger = get_logger(__name__)

@dataclass
class TrainArtifacts:
    pipeline: Pipeline
    metrics: dict
    model_path: Path
    metrics_path: Path

def train_and_save(
    df: pd.DataFrame,
    *,
    target: str,
    drop_columns: list[str],
    test_size: float,
    seed: int,
    model_type: str,
    model_cfg: dict,
    model_dir: str,
    model_name: str,
    metrics_name: str,
) -> TrainArtifacts:
    preprocessor, _ = build_preprocessor(df, target=target, drop_columns=drop_columns)

    X = df.drop(columns=[target])
    y = df[target].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=seed, stratify=y
    )

    model = build_model(model_type, model_cfg)

    clf = Pipeline(steps=[
        ("preprocess", preprocessor),
        ("model", model),
    ])

    logger.info("Training model...")
    clf.fit(X_train, y_train)

    logger.info("Evaluating model...")
    probs = clf.predict_proba(X_test)[:, 1]
    metrics = {
        "roc_auc": float(roc_auc_score(y_test, probs)),
        "avg_precision": float(average_precision_score(y_test, probs)),
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "model_type": model_type,
    }

    model_dir_path = Path(model_dir)
    model_dir_path.mkdir(parents=True, exist_ok=True)
    model_path = model_dir_path / model_name
    metrics_path = model_dir_path / metrics_name

    joblib.dump(clf, model_path)
    with metrics_path.open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    logger.info(f"Saved model -> {model_path}")
    logger.info(f"Saved metrics -> {metrics_path}")

    return TrainArtifacts(pipeline=clf, metrics=metrics, model_path=model_path, metrics_path=metrics_path)
