from pathlib import Path
import pandas as pd
from ml_pipeline.data.generate import generate_customer_churn
from ml_pipeline.utils.logging import get_logger

logger = get_logger(__name__)

def ingest_or_generate(raw_path: str, n_rows: int, seed: int) -> pd.DataFrame:
    path = Path(raw_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists():
        logger.info(f"Loading raw data from {path}")
        return pd.read_csv(path)

    logger.info(f"No raw data found. Generating synthetic dataset -> {path}")
    df = generate_customer_churn(n_rows=n_rows, seed=seed)
    df.to_csv(path, index=False)
    return df
