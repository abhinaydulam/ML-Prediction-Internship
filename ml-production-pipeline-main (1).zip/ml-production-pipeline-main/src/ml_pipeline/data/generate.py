import numpy as np
import pandas as pd

def generate_customer_churn(n_rows: int, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    df = pd.DataFrame({
        "customer_id": np.arange(1, n_rows + 1),
        "tenure_months": rng.integers(1, 72, size=n_rows),
        "monthly_charges": rng.normal(75, 25, size=n_rows).clip(10, 200),
        "contract_type": rng.choice(["month-to-month", "one-year", "two-year"], size=n_rows, p=[0.6, 0.25, 0.15]),
        "has_internet": rng.choice([0, 1], size=n_rows, p=[0.2, 0.8]),
        "support_tickets_6m": rng.poisson(1.2, size=n_rows),
        "payment_method": rng.choice(["credit_card", "bank_transfer", "paypal"], size=n_rows, p=[0.55, 0.3, 0.15]),
    })

    # Synthetic churn logic with noise
    risk = (
        0.8 * (df["contract_type"] == "month-to-month").astype(float)
        + 0.02 * (df["monthly_charges"] - 75)
        + 0.15 * df["support_tickets_6m"]
        - 0.02 * df["tenure_months"]
        + rng.normal(0, 0.7, size=n_rows)
    )
    prob = 1 / (1 + np.exp(-risk))
    df["churned"] = (rng.random(n_rows) < prob).astype(int)

    return df
