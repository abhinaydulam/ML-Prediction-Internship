from pathlib import Path
import joblib
import pandas as pd
from sklearn.metrics import classification_report

def load_pipeline(model_path: str):
    return joblib.load(model_path)

def evaluate_threshold(df: pd.DataFrame, pipeline, target: str, threshold: float) -> dict:
    X = df.drop(columns=[target])
    y = df[target].astype(int)

    probs = pipeline.predict_proba(X)[:, 1]
    preds = (probs >= threshold).astype(int)

    report = classification_report(y, preds, output_dict=True, zero_division=0)
    return {
        "threshold": float(threshold),
        "report": report,
    }

def ensure_exists(path: str) -> Path:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    return p
