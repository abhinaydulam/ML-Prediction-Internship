from ml_pipeline.cli import run_pipeline

def test_pipeline_smoke(tmp_path):
    # Use the real config but write artifacts into temp dirs by monkeypatching env is overkill.
    # This smoke test simply ensures the pipeline runs without throwing.
    result = run_pipeline("config/default.yaml")
    assert "train_metrics" in result
    assert result["train_metrics"]["roc_auc"] >= 0.5
