#!/usr/bin/env bash
set -euo pipefail

python -m ml_pipeline.cli run --config config/default.yaml
echo "Done. Model and metrics saved in ./models"
